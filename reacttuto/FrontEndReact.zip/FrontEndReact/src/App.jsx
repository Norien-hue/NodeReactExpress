import { useState, useEffect } from 'react'


function App() {
  const [nombre, setNombre] = useState('');

  useEffect(() => {
    fetch('/api/saludo').then(res => res.json()).then(data => setNombre(data.nombre)).catch(err => console.error(err));
  }, []);

  console.log(nombre)

  return (
    <>
      <h1>holaaa</h1>
      <h2>{nombre}</h2>
    </>
  )
}

export default App
